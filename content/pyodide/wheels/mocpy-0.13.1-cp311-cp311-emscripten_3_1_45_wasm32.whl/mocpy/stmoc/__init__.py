from .stmoc import STMOC

__all__ = [
    "STMOC",
]
